<?php
$numero = 10;

if($numero < 10 ){
    echo "o numero está na faixa de 0 a 10"; 
}else if($numero >=10 && $numero <= 20 ){
    echo "o numero está na faixa de 10 a 20";
} else if($numero>=21 && $numero <=30){
    echo "o numero está na faixa de 21 a 30";
}else{
    echo "o numero está na faixa de acima  30";
}






?>