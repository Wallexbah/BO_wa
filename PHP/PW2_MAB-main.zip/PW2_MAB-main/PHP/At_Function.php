<?php
 /*
  Cria uma Função com nome AumentoSalario em que tem dois argumento em que
  e dado a porcentagem de aumento, tipo de cargo, segue a lista dos salario 
  base dos cargos:

       -> Desenvolvedor Front-End r$ 3.500,00
       -> Desenvolvedor Back-End R$ 6.000,00
       -> Gerenciadado de Projeto R$ 10.000,00
       -> CEO R$ 15.000,00
       -> Estagiario R$ 699,00

    OBS: A FUNÇÃO TEM DE USAR A PALAVRA RETURN    

       */

       function AumentoSalario($porc, $cargo ){
            // salario + ( (salario * porcentagem)/100)
            if($cargo == ""){}
            else if($cargo ==""){}
            elseif($cargo ==""){}
            elseif($cargor ==""){}
            else {

            }

        return $salario ;
       }