<?php

$numero01 = 9;
$numero02 = 20;

// if($numero01 == 1 ){
//     echo "igual";
// }
if($numero01 == 2 ){
     echo "igual";
    }else{  
           echo"não achamos os numero";
       }

/*if(21 < $numero02 ){
 echo " \$numero01 é maior "; 
 echo "asdasas";
}

if($numero01 < $numero02 ){
 echo " \$numero01 é maior "; // 10 é maior
 echo "asdasas";
 echo "blalssd";

    if( ($numero01 % 2) == 0 ){
        echo "é par";
    }
*/

}



?>