<?php

$numero  = 10;


if($numero  >= 0){
    echo "positivo";
}else{
    echo "negativo";
}



?>