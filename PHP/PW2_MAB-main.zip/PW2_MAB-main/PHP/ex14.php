<?php
$variavel = 1;

// if($variavel > 10 ){
//     echo "É MAIOR QUE 10 !" ;
// }

// if($variavel < 10 ){
//     echo "NÃO É MAIOR QUE 10!";
// }

if($variavel > 10 ){
    echo "É MAIOR QUE 10 !" ;
}else{
    echo "NÃO É MAIOR QUE 10!";
}


?>