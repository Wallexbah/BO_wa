<?php
// comentario em linha
/*
  comentario em 
  bloco 
*/
// declarando variavel  PHP
$nome = "Emerson";
$idade = 50;
// exibir dados no navegador

echo " Nome : " . $nome;
echo " <br>";
echo " Idade : " .$idade;


?>