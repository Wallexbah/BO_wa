<?php
$nota1 = 7;
$nota2  = 3;


$media = ($nota1 + $nota2)/ 2;

if($media >= 6){
    echo "Aprovado";
}else{
    echo "Reprovado";
}

 echo $media;

?>